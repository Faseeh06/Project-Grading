import "./globals.css"
import { Inter } from "next/font/google"
import { initializeAppData } from "@/lib/initData"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "Chemistry Class Manager",
  description: "Manage chemistry projects and experiments efficiently",
}

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  await initializeAppData()
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  )
}

