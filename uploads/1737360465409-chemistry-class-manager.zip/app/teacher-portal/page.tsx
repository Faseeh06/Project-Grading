"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { getAssignments, createAssignment, getSubmissions, gradeSubmission, getSubmissionFile } from "@/lib/assignments"

interface Assignment {
  id: string
  title: string
  description: string
  dueDate: string
}

interface Submission {
  id: string
  assignmentId: string
  studentId: string
  studentName: string
  filename: string
  filepath: string
  grade?: number
  feedback?: string
}

export default function TeacherPortal() {
  const [assignments, setAssignments] = useState<Assignment[]>([])
  const [newAssignment, setNewAssignment] = useState({ title: "", description: "", dueDate: "" })
  const [submissions, setSubmissions] = useState<Submission[]>([])
  const [selectedSubmission, setSelectedSubmission] = useState<Submission | null>(null)

  useEffect(() => {
    fetchAssignments()
    fetchSubmissions()
  }, [])

  const fetchAssignments = async () => {
    const fetchedAssignments = await getAssignments()
    setAssignments(fetchedAssignments)
  }

  const fetchSubmissions = async () => {
    const fetchedSubmissions = await getSubmissions()
    setSubmissions(fetchedSubmissions)
  }

  const handleAddAssignment = async (e: React.FormEvent) => {
    e.preventDefault()
    await createAssignment(newAssignment)
    setNewAssignment({ title: "", description: "", dueDate: "" })
    fetchAssignments()
  }

  const handleGradeSubmission = async (e: React.FormEvent) => {
    e.preventDefault()
    if (selectedSubmission && selectedSubmission.grade !== undefined) {
      await gradeSubmission(selectedSubmission.id, selectedSubmission.grade, selectedSubmission.feedback || "")
      setSelectedSubmission(null)
      fetchSubmissions()
    }
  }

  const handleDownloadSubmission = async (submission: Submission) => {
    try {
      const fileContent = await getSubmissionFile(submission.filepath)
      const blob = new Blob([fileContent])
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = submission.filename
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    } catch (error) {
      console.error("Error downloading file:", error)
    }
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6">Teacher Portal</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Assignments</CardTitle>
            <CardDescription>Manage your class assignments</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {assignments.map((assignment) => (
                <li key={assignment.id} className="flex justify-between items-center">
                  <span>{assignment.title}</span>
                  <span className="text-sm text-gray-500">Due: {assignment.dueDate}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Add New Assignment</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAddAssignment} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Assignment Title</Label>
                <Input
                  id="title"
                  value={newAssignment.title}
                  onChange={(e) => setNewAssignment({ ...newAssignment, title: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={newAssignment.description}
                  onChange={(e) => setNewAssignment({ ...newAssignment, description: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dueDate">Due Date</Label>
                <Input
                  id="dueDate"
                  type="date"
                  value={newAssignment.dueDate}
                  onChange={(e) => setNewAssignment({ ...newAssignment, dueDate: e.target.value })}
                  required
                />
              </div>
              <Button type="submit">Add Assignment</Button>
            </form>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Submissions</CardTitle>
            <CardDescription>Grade student submissions</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {submissions.map((submission) => (
                <li key={submission.id} className="flex justify-between items-center">
                  <span>
                    {submission.studentName} - {submission.filename}
                  </span>
                  <div>
                    <Button onClick={() => handleDownloadSubmission(submission)} className="mr-2">
                      Download
                    </Button>
                    <Button onClick={() => setSelectedSubmission(submission)}>Grade</Button>
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
        {selectedSubmission && (
          <Card>
            <CardHeader>
              <CardTitle>Grade Submission</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleGradeSubmission} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="studentName">Student Name</Label>
                  <Input id="studentName" value={selectedSubmission.studentName} readOnly />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="filename">Submitted File</Label>
                  <Input id="filename" value={selectedSubmission.filename} readOnly />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="grade">Grade</Label>
                  <Input
                    id="grade"
                    type="number"
                    min="0"
                    max="100"
                    value={selectedSubmission.grade || ""}
                    onChange={(e) => setSelectedSubmission({ ...selectedSubmission, grade: Number(e.target.value) })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="feedback">Feedback</Label>
                  <Textarea
                    id="feedback"
                    value={selectedSubmission.feedback || ""}
                    onChange={(e) => setSelectedSubmission({ ...selectedSubmission, feedback: e.target.value })}
                    required
                  />
                </div>
                <Button type="submit">Submit Grade</Button>
              </form>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

