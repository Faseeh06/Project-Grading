import fs from "fs"
import path from "path"

const USERS_FILE = path.join(process.cwd(), "data", "users.json")

interface User {
  id: string
  name: string
  email: string
  password: string
  class: string
  school: string
  registrationId: string
  role: "student" | "teacher"
}

export async function ensureAdminUser() {
  const users = await getUsers()
  const adminUser = users.find((user) => user.email === "admin@gmail.com")
  if (!adminUser) {
    const newAdminUser: User = {
      id: "000",
      name: "Admin",
      email: "admin@gmail.com",
      password: "admin",
      class: "N/A",
      school: "N/A",
      registrationId: "ADMIN",
      role: "teacher",
    }
    users.push(newAdminUser)
    await saveUsers(users)
  }
}

export async function registerUser(userData: Omit<User, "id" | "role">): Promise<User> {
  const users = await getUsers()
  const newUser: User = {
    ...userData,
    id: (users.length + 1).toString().padStart(3, "0"),
    role: userData.email === "admin@gmail.com" ? "teacher" : "student",
  }
  users.push(newUser)
  await saveUsers(users)
  return newUser
}

export async function loginUser(email: string, password: string): Promise<User | null> {
  const users = await getUsers()
  return users.find((user) => user.email === email && user.password === password) || null
}

async function getUsers(): Promise<User[]> {
  if (!fs.existsSync(USERS_FILE)) {
    return []
  }
  const data = await fs.promises.readFile(USERS_FILE, "utf-8")
  return JSON.parse(data)
}

async function saveUsers(users: User[]): Promise<void> {
  await fs.promises.mkdir(path.dirname(USERS_FILE), { recursive: true })
  await fs.promises.writeFile(USERS_FILE, JSON.stringify(users, null, 2))
}

