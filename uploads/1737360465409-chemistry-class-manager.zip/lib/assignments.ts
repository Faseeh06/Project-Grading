import fs from "fs"
import path from "path"

const ASSIGNMENTS_FILE = path.join(process.cwd(), "data", "assignments.json")
const SUBMISSIONS_FILE = path.join(process.cwd(), "data", "submissions.json")
const UPLOADS_DIR = path.join(process.cwd(), "uploads")

interface Assignment {
  id: string
  title: string
  description: string
  dueDate: string
}

interface Submission {
  id: string
  assignmentId: string
  studentId: string
  studentName: string
  filename: string
  filepath: string
  grade?: number
  feedback?: string
}

export async function getAssignments(): Promise<Assignment[]> {
  if (!fs.existsSync(ASSIGNMENTS_FILE)) {
    return []
  }
  const data = await fs.promises.readFile(ASSIGNMENTS_FILE, "utf-8")
  return JSON.parse(data)
}

export async function createAssignment(assignment: Omit<Assignment, "id">): Promise<Assignment> {
  const assignments = await getAssignments()
  const newAssignment: Assignment = {
    ...assignment,
    id: (assignments.length + 1).toString().padStart(3, "0"),
  }
  assignments.push(newAssignment)
  await saveAssignments(assignments)
  return newAssignment
}

export async function getSubmissions(): Promise<Submission[]> {
  if (!fs.existsSync(SUBMISSIONS_FILE)) {
    return []
  }
  const data = await fs.promises.readFile(SUBMISSIONS_FILE, "utf-8")
  return JSON.parse(data)
}

export async function getStudentSubmissions(studentId: string): Promise<Submission[]> {
  const submissions = await getSubmissions()
  return submissions.filter((submission) => submission.studentId === studentId)
}

export async function submitAssignment(
  assignmentId: string,
  studentId: string,
  studentName: string,
  file: File,
): Promise<Submission> {
  const submissions = await getSubmissions()
  const filename = `${Date.now()}-${file.name}`
  const filepath = path.join(UPLOADS_DIR, filename)

  // Ensure uploads directory exists
  await fs.promises.mkdir(UPLOADS_DIR, { recursive: true })

  // Write file to uploads directory
  const arrayBuffer = await file.arrayBuffer()
  const buffer = Buffer.from(arrayBuffer)
  await fs.promises.writeFile(filepath, buffer)

  const newSubmission: Submission = {
    id: (submissions.length + 1).toString().padStart(3, "0"),
    assignmentId,
    studentId,
    studentName,
    filename: file.name,
    filepath,
  }
  submissions.push(newSubmission)
  await saveSubmissions(submissions)
  return newSubmission
}

export async function gradeSubmission(submissionId: string, grade: number, feedback: string): Promise<Submission> {
  const submissions = await getSubmissions()
  const submissionIndex = submissions.findIndex((s) => s.id === submissionId)
  if (submissionIndex === -1) {
    throw new Error("Submission not found")
  }
  submissions[submissionIndex] = {
    ...submissions[submissionIndex],
    grade,
    feedback,
  }
  await saveSubmissions(submissions)
  return submissions[submissionIndex]
}

async function saveAssignments(assignments: Assignment[]): Promise<void> {
  await fs.promises.mkdir(path.dirname(ASSIGNMENTS_FILE), { recursive: true })
  await fs.promises.writeFile(ASSIGNMENTS_FILE, JSON.stringify(assignments, null, 2))
}

async function saveSubmissions(submissions: Submission[]): Promise<void> {
  await fs.promises.mkdir(path.dirname(SUBMISSIONS_FILE), { recursive: true })
  await fs.promises.writeFile(SUBMISSIONS_FILE, JSON.stringify(submissions, null, 2))
}

export async function getSubmissionFile(filepath: string): Promise<Buffer> {
  return fs.promises.readFile(filepath)
}

